#pragma once
#include "Fighter.h"
class Cleric :
	public Fighter
{
private:

	int MaxMana = Magic * MANA_MULTIPLIER;
	int CurrentMana = MaxMana;

	int life_healed = Magic / life_ability_modifier;




public:
	Cleric(string newFighterName, string newFighterType, int newMaxHP, int newStrength, int newSpeed, int newMagic);

	~Cleric();


	//////GETTERS
	int getDamage();
	

	////SETTERS


	void reset();
	void regenerate();
	bool useAbility();



};

