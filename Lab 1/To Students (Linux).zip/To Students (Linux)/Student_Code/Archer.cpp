#include "Archer.h"



Archer::Archer(string newFighterName, string newFighterType, int newMaxHP, int newStrength, int newSpeed, int newMagic) : Fighter(newFighterName, newFighterType, newMaxHP, newStrength, newSpeed, newMagic)
{
	FighterName = newFighterName;
	FighterType = newFighterType;
	MaxHP = newMaxHP;
	Strength = newStrength;
	Speed = newSpeed;
	Magic = newMagic;

}


Archer::~Archer()
{
}


//////GETTERS




/////Setters

int Archer::getDamage()
{
	int speed = getSpeed();

	int damage_dealt = speed;

	return damage_dealt;
}


void Archer::reset()
{

	HitPoints = MaxHP;
	Speed = originalSpeed;

}


void Archer::regenerate()
{
	int HPModifier = Strength / STRENGTH_MODIFIER;

	int modifiedHitPoints = HitPoints + HPModifier;
	if (modifiedHitPoints >= MaxHP)
	{

	}
	else
	{
		HitPoints = modifiedHitPoints;
	}
}


bool Archer::useAbility()
{
	int ability_used = rand() % 2;

	if (ability_used == true)
	{
		Speed++;
		return true;
	}
	else
	{
		return false;
	}
}