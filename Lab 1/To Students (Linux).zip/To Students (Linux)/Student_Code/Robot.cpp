#include "Robot.h"



Robot::Robot(string newFighterName, string newFighterType, int newMaxHP, int newStrength, int newSpeed, int newMagic) : Fighter(newFighterName, newFighterType, newMaxHP, newStrength, newSpeed, newMagic)
{
	FighterName = newFighterName;
	FighterType = newFighterType;
	MaxHP = newMaxHP;
	Strength = newStrength;
	Speed = newSpeed;
	Magic = newMagic;

}


Robot::~Robot()
{
}


//////GETTERS



/////Setters

int Robot::getDamage()
{
	int strength_dealt = getStrength();
	Damage_done = strength_dealt;

	bool ability = useAbility();

	if (ability == true)
	{
		Total_Damage_Dealt = Damage_done + bonus_damage;
	}
	else
	{
		Total_Damage_Dealt = Damage_done;
	}

	return Total_Damage_Dealt;
}


void Robot::reset()
{

	HitPoints = MaxHP;
	Energy = Max_Energy;
	bonus_damage = RESET_BONUS_DMG;

}


void Robot::regenerate()
{
	int HPModifier = Strength / STRENGTH_MODIFIER;

	int modifiedHitPoints = HitPoints + HPModifier;
	if (modifiedHitPoints >= MaxHP)
	{

	}
	else
	{
		HitPoints = modifiedHitPoints;
	}
}


bool Robot::useAbility()
{
	double damage_modifier = Strength * pow((Energy / Max_Energy), ENERGY_MODIFIER);
	bonus_damage = damage_modifier;


	int ability_used = rand() % 2;

	if (ability_used == true)
	{
		if (Energy >= ROBOT_ABILITY_COST)
		{
			return true;

		}
		else
		{
			return false;
		}

	}
	else
	{
		return false;
	}
}