#include "Cleric.h"



Cleric::Cleric(string newFighterName, string newFighterType, int newMaxHP, int newStrength, int newSpeed, int newMagic) : Fighter(newFighterName, newFighterType, newMaxHP, newStrength, newSpeed, newMagic)
{
	FighterName = newFighterName;
	FighterType = newFighterType;
	MaxHP = newMaxHP;
	Strength = newStrength;
	Speed = newSpeed;
	Magic = newMagic;
}


Cleric::~Cleric()
{
}


//////GETTERS


/////Setters

int Cleric::getDamage()
{
	int magic_dealt = getMagic();

	int damage_dealt = magic_dealt;

	return damage_dealt;
}


void Cleric::reset()
{

	HitPoints = MaxHP;
	CurrentMana = MaxMana;

}


void Cleric::regenerate()
{
	int HPModifier = Strength / STRENGTH_MODIFIER;
	int ManaModifier = Magic / MANA_MULTIPLIER;

	int modifiedHitPoints = HitPoints + HPModifier;
	if (modifiedHitPoints >= MaxHP)
	{

	}
	else
	{
		HitPoints = modifiedHitPoints;
	}

	int modifiedMana = CurrentMana + ManaModifier;
	if (modifiedMana >= MaxMana)
	{

	}
	else
	{
		CurrentMana = modifiedMana;
	}

}


bool Cleric::useAbility()
{

	int ability_used = rand() % 2;

	if (ability_used == true)
	{
		if (CurrentMana >= CLERIC_ABILITY_COST)
		{
			if (HitPoints <= MaxHP)
			{
				if (MaxHP >= (HitPoints + life_healed))
				{
					HitPoints = HitPoints + life_healed;

					return true;
				}
				else
				{
					HitPoints = MaxHP;

					return true;
				}
			}
		}
		else
		{
			return false;
		}

	}
	else
	{
		return false;
	}
}